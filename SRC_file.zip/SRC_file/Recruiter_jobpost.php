<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style.css"/>
</head>
<body>

    
    <div class="container">
        <div class="apply-box">
            <h1>Job Post</h1>
            <form method="post" action="insert.php">
            
            
                <div class="form-container">
                    <div class="form-control">
                        <label for="job_ID">Job ID</label>
                        <input type="text"id="job_ID" name="job_ID" 
                        placeholder="Enter job ID">
                     </div>

                     <div class="form-control">
                        <label for="job_title">Job Title</label>
                        <input type="text"id="job_title" name="job_title" 
                        placeholder="Enter job title">
                     </div>

                     <div class="form-control">
                        <label for="description">Description</label>
                        <textarea name="description"id="" cols="30" rows="10"
                        placeholder="Enter the Description"></textarea>
                     </div>
                    
                     <div class="form-control">
                        <label for="company_name">Company Name</label>
                        <input type="text"id="company_name" name="company_name" 
                        placeholder="Enter company name">
                     </div>

                     <div class="form-control">
                        <label for="location">Location</label>
                        <select name="location" id="location">
                            <option value="district">Ampara</option>
                        </select>
                     </div>
                     

  <script>
  var select = document.getElementById("location");

  var items = [
    "Anuradhapura",
    "Badulla",
    "Batticaloa",
    "Colombo",
    "Galle",
    "Gampaha",
    "Hambantota",
    "Jaffna",
    "Kalutara",
    "Kandy",
    "Kegalle",
    "Kilinochchi",
    "Kurunegala",
    "Mannar",
    "Matale",
    "Matara",
    "Moneragala",
    "Mullativu",
    "Nuwara Eliya",
    "Polonnaruwa",
    "Puttalam",
    "Ratnapura",
    "Trincomalee",
    "Vavuniya",
    // Add more items here
  ];

  items.forEach(function(item) {
    var option = document.createElement("option");
    option.value = "district";
    option.textContent = item;
    select.appendChild(option);
  });
</script>
<div class="form-control">
                        <label for="job_type">Job Type</label>
                        <select name="job_type" id="job_type">
                            <option value="job_type"> full time</option>
                            <option value="job_type"> part time</option>
                        </select>
                     </div>     
                     

                     <div class="form-control">
                        <label for="email">Email</label>
                        <input type="email"id="email" name="email" 
                        placeholder="Enter email">
                     </div>  

                     <div class="form-control">
                        <label for="date"> Expire Date</label>
                        <input type="datetime-local"id="date" name="date" value="2024-05-05">
                     </div> 

                     <div class="form-control">
                        <label for="image">company image</label>
                        <input type="file"id="image" name="image">
                     </div>  

                     <div class="form-control">
                        <label for="update">updated at</label>
                        <input type="datetime-local"id="update" name="update">
                     </div> 

                     <div class="button-container">
                        <button type="submit"> save vacancy</button>
                     </div>
                     
                     


                </div>
            </form>
        </div>
    </div>
</body>
</html>