<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="footerstyles.css">
</head>
<body>
    
<footer class="footer">
        <div class="footer_logo">
            <img src="your_logo.png" alt="Logo">
        </div>
        <div class="footer_links">
            <a href="#">Privacy Policy</a>
            <a href="#">User Login</a>
            <a href="#">Recruiter Login</a>
            <a href="#">About Us</a>
        </div>
        <div class="social_media_icons">
            <a href="#"><img src="/src/images/insta1.png" alt="Instagram"></a>
            <a href="#"><img src="/src/images/facebook.png" alt="Facebook"></a>
            <a href="#"><img src="/src/images/linkdin.png" alt="LinkedIn"></a>
        </div>
    </footer>
</body>


</body>
</html>
