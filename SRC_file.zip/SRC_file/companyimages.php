<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="companyimages.css">
</head>
<body>
<?php

include 'connection.php';

function displayCompanyImages($conn) {
    $sql = "SELECT company_image FROM job_post";
    $result = $conn->query($sql);

    if (!$result) {
        // Query execution failed, display error message
        echo "Error: " . $conn->error;
    } elseif ($result->num_rows > 0) {
        // Process results
        while($row = $result->fetch_assoc()) {
            // Output list item with company image, job title, and count
            echo "<div class='company_image'>";
            echo "<img src='data:image/jpeg;base64," . base64_encode($row["company_image"]) . "' alt='Company Image' width='50' height='50'>";
            echo "</div>";
        }
    } else {
        // No data available
        echo "No data available";
    }
}

displayCompanyImages($conn);

?>
</body>
</html>

