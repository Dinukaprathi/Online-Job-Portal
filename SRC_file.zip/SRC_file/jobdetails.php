<?php
include 'connection.php';

// Retrieve job ID from URL parameter
if(isset($_GET['job_id'])) {
    $job_id = $_GET['job_id'];
    
    // Fetch job details based on job ID from the database
    $sql = "SELECT * FROM job_post WHERE job_ID = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $job_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        // Display job details
        while ($row = $result->fetch_assoc()) {
            echo "<div class='job_details'>";
            echo "<h2>" . $row["job_title"] . "</h2>";
            echo "<p><strong>Company Name:</strong> " . $row["company_name"] . "</p>";
            echo "<p><strong>Location:</strong> " . $row["location"] . "</p>";
            // Display "Apply on Email" with the job's email
            echo "<p><strong>Apply on Email:</strong> " . $row["email"] . "</p>";
            echo "<p><strong>Expire Date:</strong> " . $row["expire_date"] . "</p>";
            // Display company logo (assuming it's stored as a URL in the database)
            echo "<div class='company_logo'>";
            $imageData = $row["company_image"];
            echo '<img src="data:image/jpeg;base64,' . base64_encode($imageData) . '" />';
            // Apply Directly button with a link to the login page
            echo "<a href='login.php'><button>Apply Directly</button></a>";
            echo "</div>";
        }
    } else {
        echo "No job details found for the provided job ID";
    }
} else {
    echo "Job ID not provided";
}
?>
